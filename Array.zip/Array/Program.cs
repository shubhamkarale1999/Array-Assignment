﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Class2.Execute();
            //Class3.Execute();
            //Class4.Execute();
            //Class5.Execute();
            //Class6.Execute();
            //Class7.Execute();
            //Class8.Execute();
            Class9.Execute();
            //Class10.Execute();
           // Class11.Execute();


        }
    }
}
